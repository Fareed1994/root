//  Created by Alasiri, Fareed on 12/19/24.
#ifndef UTILITIES_HPP
#define UTILITIES_HPP

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <regex>
#include <ginac/ginac.h>

using namespace GiNaC;

int CreatePDFLatex(std::string LatexExpression, std::string FileName);
std::string ConvertMatrix2String(std::vector<std::vector<ex>> matrix);

#endif
