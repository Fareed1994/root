//  Created by Fareed on 12/16/24.

#ifndef USEDFUNCTIONS_HPP
#define USEDFUNCTIONS_HPP

#include <iostream>
#include <format>
#include <string>
#include <numeric>
#include <ginac/ginac.h>

using namespace GiNaC;

ex Simplify(ex expression);
ex Wigner3J(ex j1, ex m1, ex j2, ex m2, ex j3, ex m3);
ex CleschGordan(ex j1, ex m1, ex j2, ex m2, ex J, ex M);
ex Wigner6J(ex j1, ex j2, ex j3, ex j4, ex j5, ex j6);
#endif
