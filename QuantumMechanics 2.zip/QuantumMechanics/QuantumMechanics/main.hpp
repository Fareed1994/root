//  Created by Fareed on 12/16/24.

#ifndef MAIN_HPP
#define MAIN_HPP

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>

#include <ginac/ginac.h>
//#include <Eigen/Dense>

//#include <QApplication>
//#include <QLabel>
//#include <QString>

#include "UsedFunctions.hpp"
#include "Utilities.hpp"

#endif

