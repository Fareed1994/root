//  Created by Fareed on 12/16/24.
#include "UsedFunctions.hpp"

ex Simplify(ex expression){
    numeric sign = 1;
    if (expression != abs(expression)){sign = -1;}
    expression *= expression;
    ex a = numer(expression);
    ex b = denom(expression);
    ex prefactor = gcd(a, b);
    a /= prefactor;
    b /= prefactor;
    expression = a/b;
    return sign * sqrt(expression);
}
ex Wigner3J(ex j1, ex m1, ex j2, ex m2, ex j3, ex m3){
    //Definiton taken from https://en.wikipedia.org/wiki/3-j_symbol;
    
    if ( j1 + j2 < j3 || j3 < abs(j1-j2) ){
        //std::cerr << "Wigner3J("<< j1 <<", "<< m1 <<", "<< j2 <<", "<< m2 <<", "<< j3 <<", "<< m3 <<") is not triangular!"<< std::endl;
        return 0;
    }
    
    if (m1 + m2 + m3 != 0){
        //std::cerr << "Wigner3J("<< j1 <<", "<< m1 <<", "<< j2 <<", "<< m2 <<", "<< j3 <<", "<< m3 <<") is not physical!"<< std::endl;
        return 0;
    }
    
    int K = std::max({0, ex_to<numeric>(j2 - j3 - m1).to_int(), ex_to<numeric>(j1 - j3 + m2).to_int()});
    int N = std::min({ex_to<numeric>(j1 + j2 - j3).to_int(), ex_to<numeric>(j1 - m1).to_int(), ex_to<numeric>(j2 + m2).to_int()});

    ex Sum = 0;
    for (int i=K; i<=N; i++){
        Sum += pow(ex_to<numeric>(-1), ex_to<numeric>(i)) / (factorial(ex_to<numeric>(i)) * factorial(j1 + j2 - j3 - ex_to<numeric>(i)) * factorial(j1 - m1 - ex_to<numeric>(i)) * factorial(j2 + m2 - ex_to<numeric>(i)) * factorial(j3 - j2 + m1 + ex_to<numeric>(i)) * factorial(j3 - j1 - m2 + ex_to<numeric>(i)));
    }

    ex MainExpression = pow(ex_to<numeric>(-1), j1-j2-m3) * sqrt(factorial(j1 + j2 - j3) * factorial(j1 - j2 + j3) * factorial(-j1 + j2 + j3)/factorial(j1 + j2 + j3 + ex_to<numeric>(1))) * sqrt(factorial(j1 - m1) * factorial(j1 + m1) * factorial(j2 - m2) * factorial(j2 + m2) * factorial(j3 - m3) * factorial(j3 + m3));
    
    return Simplify(MainExpression * Sum);
}

ex CleschGordan(ex j1, ex m1, ex j2, ex m2, ex J, ex M){
    //Definiton taken from https://en.wikipedia.org/wiki/Clebsch–Gordan_coefficients;
    ex Prefactor = pow(ex_to<numeric>(-1), -j1+j2-M) * sqrt(2 * J + ex_to<numeric>(1));
    return Simplify(Prefactor * Wigner3J(j1, m1, j2, m2, J, -M));
}

ex Wigner6J(ex j1, ex j2, ex j3, ex j4, ex j5, ex j6){
    //Definiton taken from https://en.wikipedia.org/wiki/6-j_symbol;
    std::vector<ex> m1(ex_to<numeric>(2*j1).to_int()+1);
    std::vector<ex> m2(ex_to<numeric>(2*j2).to_int()+1);
    std::vector<ex> m3(ex_to<numeric>(2*j3).to_int()+1);
    std::vector<ex> m4(ex_to<numeric>(2*j4).to_int()+1);
    std::vector<ex> m5(ex_to<numeric>(2*j5).to_int()+1);
    std::vector<ex> m6(ex_to<numeric>(2*j6).to_int()+1);
    
    std::vector<ex> j = {j1, j2, j3, j4, j5, j6};
    std::vector<std::vector<ex>> m = {m1, m2, m3, m4, m5, m6};
    
    for (int k=0; k<m.size(); k++){
        ex count = 0;
        for (int l=0; l<m[k].size(); l++){
            m[k][l] = -j[k] + count;
            count++;
        }
    }

    ex FinalSum = 0;
    ex LCD = 1;
    for (const ex& m1_i : m[0]){
        for (const ex& m2_i : m[1]){
            for (const ex& m3_i : m[2]){
                for (const ex& m4_i : m[3]){
                    for (const ex& m5_i : m[4]){
                        for (const ex& m6_i : m[5]){
                            ex Prefactor = pow(ex_to<numeric>(-1), (j1-m1_i) + (j2-m2_i)+ (j3-m3_i) + (j4-m4_i) + (j5-m5_i) + (j6-m6_i));
                            ex Expression = Prefactor * Wigner3J(j1, -m1_i, j2, -m2_i, j3, -m3_i)
                            * Wigner3J(j1, m1_i, j5, -m5_i, j6, m6_i)
                            * Wigner3J(j4, m4_i, j2, m2_i, j6, -m6_i)
                            * Wigner3J(j4, -m4_i, j5, m5_i, j3, m3_i);
                            FinalSum += normal(Expression);
                            LCD *= denom(FinalSum);
                            FinalSum = ( numer(FinalSum)*LCD ) / ( denom(FinalSum)*LCD );
                            
                        }
                    }
                }
            }
        }
    }
    return FinalSum;
}
