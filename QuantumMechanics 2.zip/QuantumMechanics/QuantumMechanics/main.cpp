//  Created by Fareed on 12/16/24.
#include "main.hpp"
#include <numeric>

using namespace GiNaC;

int main(int argc, char *argv[]) {

    numeric b(sqrt(3),2);
    ex c = sqrt(2)/3;
    numeric f = 2;
    ex d = sqrt(f);
    
    numeric a1 = 2;
    numeric a2 = 3;
    numeric a3 = 5;
    
    
    ex result1 = Wigner3J(1, 1, 2, -1, 1, 0);
    ex result2 = CleschGordan(1, 1, 2, -1, 1, 0);
    ex result3 = Wigner6J(3,2,1,2,1,2);
    
    std::cout << latex;
    std::cout << "num = " << d << std::endl;
    std::cout << "den = " << denom(c) << std::endl;
    std::cout << "result1 = " << result1 << std::endl;
    std::cout << "result2 = " << result2 << std::endl;
    std::cout << "result3 = " << result3 << std::endl;

    std::vector<std::vector<ex>> matrix = {{a1, b},{result1, result3}};
    std::string str = ConvertMatrix2String(matrix);
    int status = CreatePDFLatex(str, "TexTest1");

     return 0;

}






    // Enable stack traces on segfault for debugging
    

