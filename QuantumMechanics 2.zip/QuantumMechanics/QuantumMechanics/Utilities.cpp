#include "Utilities.hpp"

std::string CaptureCoutOutput(const std::function<void()>& func) {
    std::ostringstream buffer;
    std::streambuf* oldCoutBuffer = std::cout.rdbuf(); // Save the original buffer
    std::cout.rdbuf(buffer.rdbuf());                  // Redirect std::cout to the buffer

    func(); // Execute the function that writes to std::cout

    std::cout.rdbuf(oldCoutBuffer); // Restore the original std::cout buffer
    return buffer.str(); // Get the captured output as a string
}

int CreatePDFLatex(std::string LatexExpression, std::string FileName){

    std::ofstream outFile(FileName);
    if (outFile.is_open()) {
        outFile << "\\documentclass{article}\n";
        outFile << "\\usepackage{amsmath}\n";
        outFile << "\\usepackage{booktabs}\n";
        outFile << "\\usepackage{multirow}\n";
        outFile << "\\usepackage{mathtools}\n";
        outFile << "\\usepackage{tabularx}\n";
        outFile << "\\usepackage{placeins}\n";
        outFile << "\\begin{document}\n";
        outFile << LatexExpression;
        outFile << "\\end{document}\n";
        outFile.close();
        std::cout << "LaTeX file created successfully.\n";
    } else {
        std::cerr << "Error: Could not open file for writing.\n";
        return 1;
    }
    
    std::string compileCommand = "/Library/TeX/texbin/pdflatex " + FileName;
    int compileStatus = system(compileCommand.c_str());
    if (compileStatus == 0) {
        std::cout << "PDF compiled successfully.\n";
        
        std::string openCommand = "open " + FileName + ".pdf";
        int openStatus = system(openCommand.c_str());
        if (openStatus != 0) {
            std::cerr << "Error: Could not open PDF file.\n";
            return 1;
        }
    } else {
        std::cerr << "Error: Failed to compile LaTeX file.\n";
        return 1;
    }
    return 0;
}

std::string ConvertMatrix2String(std::vector<std::vector<ex>> matrix){
    if (matrix.size() != matrix[0].size()){return "This requires a square matrix!";}
    std::string Expression = "{\\Large \n \\[ \n \\begin{bmatrix} \n";
    for (int i=0; i<matrix.size(); i++){
        for (int j=0; j<matrix[0].size(); j++){
            std::cout << latex;
            std::ostringstream oss;
            std::streambuf* old_cout = std::cout.rdbuf();
            std::cout.rdbuf(oss.rdbuf());
            std::cout << matrix[i][j];
            std::string captured = oss.str();
            std::cout.rdbuf(old_cout);
            Expression += captured + "&";
        }
        Expression += "\\\\ \n";
    }
    Expression += "\\end{bmatrix} \n \\] \n }";
    return Expression;
}
