//  Created by Fareed on 12/16/24.

#ifndef USEDFUNCTIONS_HPP
#define USEDFUNCTIONS_HPP

#include <iostream>
#include <format>
#include <string>
#include <ginac/ginac.h>

using namespace GiNaC;

ex Wigner3J(numeric j1, numeric m1, numeric j2, numeric m2, numeric j3, numeric m3);

#endif
