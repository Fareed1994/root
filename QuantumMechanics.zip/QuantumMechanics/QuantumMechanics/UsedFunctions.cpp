//  Created by Fareed on 12/16/24.
#include "UsedFunctions.hpp"

ex Wigner3J(numeric j1, numeric m1, numeric j2, numeric m2, numeric j3, numeric m3){
    //Definiton taken from https://en.wikipedia.org/wiki/3-j_symbol;
    
    if ( j1 + j2 < j3 || j3 < abs(j1-j2) ){
        std::cerr << "Wigner3J("<< j1 <<", "<< m1 <<", "<< j2 <<", "<< m2 <<", "<< j3 <<", "<< m3 <<") is not triangular!"<< std::endl;
        return 0;
    }
    
    if (m1 + m2 + m3 != 0){
        std::cerr << "Wigner3J("<< j1 <<", "<< m1 <<", "<< j2 <<", "<< m2 <<", "<< j3 <<", "<< m3 <<") is not physical!"<< std::endl;
        return 0;
    }
    
    int K = std::max({0, ex_to<numeric>(j2 - j3 - m1).to_int(), ex_to<numeric>(j1 - j3 + m2).to_int()});
    int N = std::min({ex_to<numeric>(j1 + j2 - j3).to_int(), ex_to<numeric>(j1 - m1).to_int(), ex_to<numeric>(j2 + m2).to_int()});

    ex Sum = 0;
    for (int i=K; i<=N; i++){
        Sum += pow(ex_to<numeric>(-1), ex_to<numeric>(i)) / (factorial(ex_to<numeric>(i)) * factorial(j1 + j2 - j3 - ex_to<numeric>(i)) * factorial(j1 + m1 - ex_to<numeric>(i)) * factorial(j2 + m2 - ex_to<numeric>(i)) * factorial(j3 - j2 + m1 + ex_to<numeric>(i)) * factorial(j3 - j1 - m2 + ex_to<numeric>(i)));
    }

    ex numerator = factorial(j1 + j2 - j3) * factorial(j1 - j2 + j3) * factorial(-j1 + j2 + j3);
    
    ex denomenator = factorial(j1 + j2 + j3 + ex_to<numeric>(1));
    
    ex SqrtArgument = factorial(j1 - m1) * factorial(j1 + m1) * factorial(j2 - m2) * factorial(j2 + m2) * factorial(j3 - m3) * factorial(j3 + m3);
    
    ex MainExpression = pow(ex_to<numeric>(-1), j1-j2-m3) * sqrt(numerator/denomenator) * sqrt(SqrtArgument);
    
    std::cout << "MainExpression = " << MainExpression << std::endl;
    std::cout << "Sum = " << Sum << std::endl;
    return MainExpression * Sum;

}
