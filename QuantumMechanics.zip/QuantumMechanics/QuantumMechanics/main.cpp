//  Created by Fareed on 12/16/24.
#include "main.hpp"
#include <numeric>

using namespace GiNaC;

int main() {
    numeric a(1,3);
    numeric b(1,2);
    numeric c(-1,2);
    
    ex n = 5;
    ex m = 4;

    ex result1 = sqrt(n/m);
    ex result2 = Wigner3J(b, b, b, b, 1, -1);
    
    std::cout << "result1 = " << result1 << std::endl;
    std::cout << "result2 = " << result2 << std::endl;
    
    double val = 0.3333;
    long long denom = 12; // guess a denominator scale
    long long num = 2; //static_cast<long long>(std::round(val * denom));
    
    // for std::gcd
    long long g = std::gcd(num, denom);
    num /= g;
    denom /= g;
    
    std::cout << num << ", "<< denom << std::endl;
    
    return 0;
}




