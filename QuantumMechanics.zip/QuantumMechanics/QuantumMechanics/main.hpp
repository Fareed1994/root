//  Created by Fareed on 12/16/24.

#ifndef MAIN_HPP
#define MAIN_HPP

#include <iostream>
#include <string>
#include <ginac/ginac.h>
//#include <Eigen/Dense>

#include "UsedFunctions.hpp"



#endif

